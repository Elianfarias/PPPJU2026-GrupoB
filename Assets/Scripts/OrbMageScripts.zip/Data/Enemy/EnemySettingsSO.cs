using UnityEngine;

namespace Assets.Scripts.Gameplay.Enemy
{
    [CreateAssetMenu(fileName = "EnemySettings", menuName = "OrbMage/Enemy Settings")]
    public class EnemySettingsSO : ScriptableObject
    {
        [Header("Combat")]
        [SerializeField] private int damage = 10;
        [SerializeField] private float attackRange = 2f;
        [SerializeField] private float attackCooldown = 1.5f;

        [Header("Detection")]
        [SerializeField] private float playerDetectionRadius = 15f;
        [SerializeField] private float playerLoseRadius = 20f;
        [SerializeField] private LayerMask playerLayer;

        [Header("Wandering")]
        [SerializeField] private float wanderRadius = 10f;
        [SerializeField] private float wanderCooldown = 3f;
        [SerializeField] private float obstacleDetectionRadius = 1.5f;
        [SerializeField] private LayerMask enemyLayer;

        [Header("Animation")]
        [SerializeField] private string attackAnimationName = "Attack";

        public int Damage => damage;
        public float AttackRange => attackRange;
        public float AttackCooldown => attackCooldown;

        public float PlayerDetectionRadius => playerDetectionRadius;
        public float PlayerLoseRadius => playerLoseRadius;
        public LayerMask PlayerLayer => playerLayer;

        public float WanderRadius => wanderRadius;
        public float WanderCooldown => wanderCooldown;
        public float ObstacleDetectionRadius => obstacleDetectionRadius;
        public LayerMask EnemyLayer => enemyLayer;

        public string AttackAnimationName => attackAnimationName;
    }
}
