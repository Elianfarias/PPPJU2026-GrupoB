using Assets.Scripts.Gameplay.Enemy.States;
using Assets.Scripts.Gameplay.System.Elemental;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace Assets.Scripts.Gameplay.Enemy
{
    [RequireComponent(typeof(NavMeshAgent))]
    [RequireComponent(typeof(Animator))]
    [RequireComponent(typeof(HealthSystem))]
    [RequireComponent(typeof(CapsuleCollider))]
    [RequireComponent(typeof(ElementalStateHandler))]
    public class FsmEnemyManager : MonoBehaviour
    {
        [SerializeField] private EnemySettingsSO enemySettings;

        private EnemyContext context;
        private readonly List<StateBase> stateBases = new();
        private StateBase currentState;

        private void Awake()
        {
            context = BuildContext();
            RegisterStates();
            InitializeStates();
            currentState = FindState(EnemyStateType.Idle);
            currentState.OnEnter();
        }

        private void Update()
        {
            currentState.OnUpdate();
        }

        private void OnAnimatorIK(int layerIndex)
        {
            currentState.OnAnimatorIK(layerIndex);
        }

        public void SwitchState(StateBase newState)
        {
            if (newState == null || currentState == newState) return;

            currentState.OnExit();
            currentState = newState;
            currentState.OnEnter();
        }

        public StateBase FindState(EnemyStateType stateType)
        {
            foreach (var state in stateBases)
            {
                if (state.StateType == stateType)
                    return state;
            }
            return null;
        }

        public Coroutine StartManagedCoroutine(IEnumerator routine)
        {
            return StartCoroutine(routine);
        }

        private EnemyContext BuildContext()
        {
            var player = GameObject.FindGameObjectWithTag("Player");

            return new EnemyContext
            {
                Manager = this,
                Animator = GetComponent<Animator>(),
                Settings = enemySettings,
                Agent = GetComponent<NavMeshAgent>(),
                Player = player != null ? player.transform : null,
                HealthSystem = GetComponent<HealthSystem>(),
                CapsuleCollider = GetComponent<CapsuleCollider>(),
                StateHandler = GetComponent<ElementalStateHandler>(),
                Resolver = GetComponent<ReactionResolver>()
            };
        }

        private void RegisterStates()
        {
            stateBases.Add(new StateIdle());
            stateBases.Add(new StateChase());
            stateBases.Add(new StateAttack());
            stateBases.Add(new StateDying());
        }

        private void InitializeStates()
        {
            foreach (var state in stateBases)
                state.Initialize(context);
        }
    }
}
